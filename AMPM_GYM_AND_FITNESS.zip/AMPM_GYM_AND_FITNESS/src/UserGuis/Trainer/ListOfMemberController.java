package UserGuis.Trainer;

import Classes.SuspendAccount;
import Classes.Trainer;
import Classes.User;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ListOfMemberController implements Initializable {

    ObservableList<SuspendAccount> accountInformation = FXCollections.observableArrayList();

    @FXML
    private TableView<SuspendAccount> memberInformation;
    @FXML
    private TableColumn<SuspendAccount, String> id;
    @FXML
    private TableColumn<SuspendAccount, String> name;
    @FXML
    private TableColumn<SuspendAccount, String> dob;

    private Trainer selectedTrainer;

    public void passData(User m) {
        selectedTrainer = (Trainer) m;
        searchingMember();
        memberInformation.setItems(accountInformation);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        id.setCellValueFactory(new PropertyValueFactory<SuspendAccount, String>("id"));
        name.setCellValueFactory(new PropertyValueFactory<SuspendAccount, String>("name"));
        dob.setCellValueFactory(new PropertyValueFactory<SuspendAccount, String>("dob"));
        
    }

    void searchingMember() {
        File f = null;
        FileInputStream fis = null;
        DataInputStream dis = null;
        
        try {
            f = new File("selectedTrainerInformation.bin");
            if (!f.exists()) {

            } else {
                
                fis = new FileInputStream(f);
                dis = new DataInputStream(fis);
                while (true) {
                    
                    String trainerName = dis.readUTF();
                    String memberID = dis.readUTF();
                    if (trainerName.equals(selectedTrainer.getName())) {
                       
                            addAccountInformation(memberID);
                    }
                }
            }
        } catch (IOException ex) {
            
        } finally {
            try {
                if (dis != null) {
                    dis.close();
                }
            } catch (IOException ex) {
                
            }
        }          
    
    }
    void addAccountInformation(String memberID) {
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        f = new File("user.bin");
        if (!f.exists()) {

        } else {
            try {
                fis = new FileInputStream(f);
                ois = new ObjectInputStream(fis);
                User u;
                try {
                    while (true) {

                        u = (User) ois.readObject();
                        if (!u.getIsSuspend() && !u.getDeleteAccount() && u.getId().equals(memberID)) {
                            SuspendAccount s = new SuspendAccount(u.getName(), u.getId(), u.getDob());
                            accountInformation.add(s);
                        }
                    }
                } catch (Exception e) {
                }
            } catch (IOException ex) {
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException ex) {
                }
            }
        }

    }

    @FXML
    private void backButtonOnClick(ActionEvent event) throws IOException {
        
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("TrainerMainPanel.fxml"));
        Parent personViewParent = loader.load();
        Scene personViewScene = new Scene(personViewParent);
       TrainerMainPanelController controller2 = loader.getController();
        controller2.passData((User)selectedTrainer);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(personViewScene);
        window.show();
    }

}
