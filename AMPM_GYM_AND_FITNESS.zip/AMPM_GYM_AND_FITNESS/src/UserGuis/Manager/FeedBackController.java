/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserGuis.Manager;

import Classes.Manager;
import Classes.Trainer;
import Classes.User;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FeedBackController implements Initializable {

    @FXML
    private TextField feedback;
    @FXML
    private ComboBox Trainer;

    /**
     * Initializes the controller class.
     */
    private Manager selectedManeger;

    public void passData(Manager m) {
        selectedManeger = m;
        System.out.println(selectedManeger.getName());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        listOfaccount();
        Trainer.setValue("");
        Trainer.setItems(totalTrainer);
    }

    @FXML
    private void backOnClick(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ManagerMainPanel.fxml"));
        Parent personViewParent = loader.load();
        Scene personViewScene = new Scene(personViewParent);
        ManagerMainPanelController controller2 = loader.getController();
        controller2.passData((User) selectedManeger);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(personViewScene);
        window.show();
    }

    @FXML
    private void submitButtonOnClick(ActionEvent event) {
        String trainer = Trainer.getSelectionModel().getSelectedItem().toString();
        if (feedback.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Please enter your Feedback.");
            alert.showAndWait();
        } else {
            File f = null;
            FileOutputStream fos = null;
            BufferedOutputStream bos = null;
            DataOutputStream dos = null;
            try {
                f = new File("FeedBack.bin");
                if (f.exists()) {
                    fos = new FileOutputStream(f, true);
                } else {
                    fos = new FileOutputStream(f);
                }
                bos = new BufferedOutputStream(fos);
                dos = new DataOutputStream(bos);
                dos.writeUTF(selectedManeger.getName());
                dos.writeUTF(trainer);
                dos.writeUTF(feedback.getText().toString());

            } catch (IOException ex) {
            } finally {
                try {
                    if (dos != null) {
                        dos.close();
                    }
                } catch (IOException ex) {

                }
            }
        }
        Trainer.setValue("");
        feedback.setText("");
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText("Successfully Done...");
            alert.showAndWait();
    }

    ObservableList<String> totalTrainer = FXCollections.observableArrayList();

    void listOfaccount() {
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;
        try {
            f = new File("user.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            User u;
            try {
                while (true) {
                    u = (User) ois.readObject();

                    if (u instanceof Trainer) {

                        totalTrainer.add(u.getName());
                    }
                }
            } catch (Exception e) {
            }
        } catch (IOException ex) {
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex) {
            }
        }
    }

}
