package UserGuis.Manager;

import Classes.Manager;
import Classes.Trainer;
import Classes.User;
import UserGuis.Trainer.TrainerMainPanelController;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

public class ReportController implements Initializable {

    @FXML
    private ComboBox trainer;
    @FXML
    private BarChart<String, Number> barChart;

    private Manager selectedManeger = null;
    private Trainer selectedTrainer = null;
    int totalQ1 = 0;
    int totalQ2 = 0;
    int totalQ3 = 0;
    int total = 0;
    @FXML
    private NumberAxis yAxis;
    @FXML
    private CategoryAxis xAxis = null;

    public void passData(User m) {
        selectedManeger = (Manager) m;
        listOfTrainer();
    }
    public void TrainerInfo(User m) {
        selectedTrainer = (Trainer) m;
        trainer.setEditable(false);
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        trainer.setItems(totalTrainer);
        barChart.getData().clear();
        XYChart.Series<String, Number> series = new XYChart.Series<String, Number>();

        series.getData().add(new XYChart.Data<String, Number>("Question 1", totalQ1));
        series.getData().add(new XYChart.Data<String, Number>("Question 2", totalQ2));
        series.getData().add(new XYChart.Data<String, Number>("Question 3", totalQ3));
        series.setName("");
        barChart.getData().add(series);
    }

    void generate() {
        XYChart.Series<String, Number> series = new XYChart.Series<String, Number>();

        series.getData().add(new XYChart.Data<String, Number>("Question 1", totalQ1));
        series.getData().add(new XYChart.Data<String, Number>("Question 2", totalQ2));
        series.getData().add(new XYChart.Data<String, Number>("Question 3", totalQ3));
        
        
        if(selectedTrainer != null)
        {
            String numberAsString = String.format("%,.2f", ((totalQ1 + totalQ2 + totalQ3) / (total * 3.0) / 3 * 100));
        series.setName("Evaluation Report for " + selectedTrainer.getName()+"\n Rating is " + numberAsString + "%");
            
        }    
        else
        {
            String numberAsString = String.format("%,.2f", ((totalQ1 + totalQ2 + totalQ3) / (total * 3.0) / 3 * 100));
        series.setName("Evaluation Report Of Selectd Trainer.\n Rating is " + numberAsString + "%");
        }
        
        barChart.getData().add(series);
    }

    @FXML
    private void backButtonOnClick(ActionEvent event) throws IOException {
        
         
        if (selectedTrainer != null)
        {
            FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/UserGuis/Trainer/TrainerMainPanel.fxml"));
        Parent customer = loader.load();
        Scene customerScene = new Scene(customer);
        TrainerMainPanelController controller = loader.getController();
        controller.passData((User) selectedTrainer);
        Stage customerWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        customerWindow.setScene(customerScene);
        customerWindow.show();
        }
        else 
        {
             
        
            FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("ManagerMainPanel.fxml"));
        Parent customer = loader.load();
        Scene customerScene = new Scene(customer);
        ManagerMainPanelController controller = loader.getController();
        controller.passData((User) selectedManeger);
        Stage customerWindow = (Stage) ((Node) event.getSource()).getScene().getWindow();
        customerWindow.setScene(customerScene);
        customerWindow.show();
        
          
        }
    }

    @FXML
    private void generateButtonOnClick(ActionEvent event) {
        totalQ1 = 0;
        totalQ2 = 0;
        totalQ3 = 0;
        total = 0;
        barChart.getData().clear();
       
        String trainerName ;
        if(selectedTrainer != null)
            trainerName = selectedTrainer.getName();
           
        else 
             trainerName = trainer.getSelectionModel().getSelectedItem().toString();
        
        countingRating(trainerName);
        generate();

    }

    void countingRating(String trainerName) {
        File f = null;
        FileInputStream fis = null;
        BufferedInputStream bis = null;
        DataInputStream dis = null;

        try {
            f = new File("trainerEvaluation.bin");
            if (f.exists()) {

                fis = new FileInputStream(f);
                dis = new DataInputStream(fis);
                while (true) {

                    String memberID = dis.readUTF();
                    String tName = dis.readUTF();
                    int q1 = Integer.valueOf(dis.readUTF());
                    int q2 = Integer.valueOf(dis.readUTF());
                    int q3 = Integer.valueOf(dis.readUTF());

                    if (trainerName.equals(tName)) {
                        totalQ1 += q1;
                        totalQ2 += q2;
                        totalQ3 += q3;
                        total += 1;
                    }
                }
            }
        } catch (IOException ex) {
        } finally {
            try {
                if (dis != null) {
                    dis.close();
                }
            } catch (IOException ex) {

            }
        }
    }
    ObservableList<String> totalTrainer = FXCollections.observableArrayList();

    void listOfTrainer() {
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;
        User u = null;
        f = new File("user.bin");
        if (f.exists()) {
            try {
                fis = new FileInputStream(f);
                ois = new ObjectInputStream(fis);

                try {
                    while (true) {

                        u = (User) ois.readObject();

                        if (u instanceof Trainer && !u.getIsSuspend() && !u.getDeleteAccount()) {
                            u = (Trainer) u;
                            totalTrainer.add(u.getName());
                        }
                    }

                } catch (Exception e) {

                }
            } catch (IOException ex) {
            } finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException ex) {
                }
            }

        }
    }
}
