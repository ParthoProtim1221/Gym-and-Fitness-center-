package UserGuis.Member;

import Classes.Member;
import Classes.User;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;

public class EvaluationController implements Initializable {

    @FXML
    private ToggleGroup E1;
    @FXML
    private ToggleGroup E2;
    @FXML
    private ToggleGroup E3;

    private Member selectedMember;
    @FXML
    private RadioButton q11;
    @FXML
    private RadioButton q13;
    @FXML
    private RadioButton q12;
    @FXML
    private RadioButton q21;
    @FXML
    private RadioButton q23;
    @FXML
    private RadioButton q22;
    @FXML
    private RadioButton q31;
    @FXML
    private RadioButton q33;
    @FXML
    private RadioButton q32;
    @FXML
    private ComboBox trainer;

    public void passData(Member m) {
        selectedMember = m;
        listOfTrainer();
        trainer.setItems(totalTrainer);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }

    @FXML
    private void backButtonOnClick(ActionEvent event) throws IOException {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("MemberMainPanel.fxml"));
        Parent personViewParent = loader.load();
        Scene personViewScene = new Scene(personViewParent);
        MemberMainPanelController controller2 = loader.getController();
        controller2.passData((User) selectedMember);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(personViewScene);
        window.show();
    }

    @FXML
    private void submitButtonOnClick(ActionEvent event) {
        String q1 = "";
        String q2 = "";
        String q3 = "";
        if (q11.isSelected()) {
            q1 = "1";
        } else if (q12.isSelected()) {
            q1 = "2";
        } else if (q13.isSelected()) {
            q1 = "3";
        }
        if (q21.isSelected()) {
            q2 = "1";
        } else if (q22.isSelected()) {
            q2 = "2";
        } else if (q23.isSelected()) {
            q2 = "3";
        }
        if (q31.isSelected()) {
            q3 = "1";
        } else if (q32.isSelected()) {
            q3 = "2";
        } else if (q33.isSelected()) {
            q3 = "3";
        }

        File f = null;
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        DataOutputStream dos = null;
        try {
            System.out.println("11111");
            f = new File("trainerEvaluation.bin");
            if (f.exists()) {
                fos = new FileOutputStream(f, true);
            } else {
                fos = new FileOutputStream(f);
            }
            bos = new BufferedOutputStream(fos);
            dos = new DataOutputStream(bos);

            dos.writeUTF(selectedMember.getId());
            dos.writeUTF(trainer.getSelectionModel().getSelectedItem().toString());
            dos.writeUTF(q1);
            dos.writeUTF(q2);
            dos.writeUTF(q3);
           

        } catch (IOException ex) {
        } finally {
            try {
                if (dos != null) {
                    dos.close();
                }
            } catch (IOException ex) {

            }
        }
        ButtonType yes = new ButtonType("Yes");
        ButtonType no = new ButtonType("No");
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setContentText("Do you want to save the record? ");
        alert.getButtonTypes().clear();
        alert.getButtonTypes().addAll(yes, no);
        Optional<ButtonType> option = alert.showAndWait();
        if (option.get().equals(null)) {
            System.out.println("Print 404...!!!");
        } else if (option.get() == yes) {
            System.out.println("Successfully Done..");
        }
        q11.setSelected(false);
        q12.setSelected(false);
        q13.setSelected(false);
        q21.setSelected(false);
        q22.setSelected(false);
        q23.setSelected(false);
        q31.setSelected(false);
        q32.setSelected(false);
        q33.setSelected(false);
        trainer.setValue("");
        System.out.println("Successfully Done...");
    }
    ObservableList<String> totalTrainer = FXCollections.observableArrayList();
    
    void listOfTrainer() {
        File f = null;
        FileInputStream fis = null;
        BufferedInputStream bis = null;
        DataInputStream dis = null;
        String str = "";
        try {
            f = new File("selectedTrainerInformation.bin");
            if (f.exists()) {
               
                fis = new FileInputStream(f);

                dis = new DataInputStream(fis);

                String trinaerName;
                String memberID;
                while (true) {
                    
                    trinaerName = dis.readUTF();
                    memberID = dis.readUTF();
                    
                    if (memberID.equals(selectedMember.getId())) {
                        totalTrainer.add(trinaerName);
                        
                    }
                }
            }
        } catch (IOException ex) {
        } finally {
            try {
                if (dis != null) {
                    dis.close();
                }
            } catch (IOException ex) {

            }
        }
    }

}
