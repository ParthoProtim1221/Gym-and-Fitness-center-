/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserGuis.Member;

import Classes.Member;
import Classes.Trainer;
import Classes.User;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Acer
 */
public class SelectTrainerController implements Initializable {

    @FXML
    private ComboBox trainer;
    @FXML
    private Label label;

    /**
     * Initializes the controller class.
     */
    private Member selectedMember;

    public void passData(Member m) {
        selectedMember = m;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        listOfaccount();
        trainer.setValue("");
        trainer.setItems(totalTrainer);
    }

    @FXML
    private void submitButtonOnClick(ActionEvent event) {
        String Trainer = trainer.getSelectionModel().getSelectedItem().toString();
        if (Trainer.equals("")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Select your Trainer...");
            alert.showAndWait();
        } else {
            File f = null;
            FileOutputStream fos = null;
            BufferedOutputStream bos = null;
            DataOutputStream dos = null;
            try {
                f = new File("selectedTrainerInformation.bin");
                if (f.exists()) {
                    fos = new FileOutputStream(f, true);
                } else {
                    fos = new FileOutputStream(f);
                }
                bos = new BufferedOutputStream(fos);
                dos = new DataOutputStream(bos);
                dos.writeUTF(Trainer);
                dos.writeUTF(selectedMember.getId());

            } catch (IOException ex) {
            } finally {
                try {
                    if (dos != null) {
                        dos.close();
                    }
                } catch (IOException ex) {

                }
            }
        }
        trainer.setValue("");
        label.setText("Successfully Done ...");
    }

    @FXML
    private void backButtonOnClick(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/UserGuis/Member/MemberMainPanel.fxml"));
        Parent personViewParent = loader.load();
        Scene personViewScene = new Scene(personViewParent);
        MemberMainPanelController controller2 = loader.getController();
        controller2.passData(selectedMember);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(personViewScene);
        window.show();
    }
    ObservableList<String> totalTrainer = FXCollections.observableArrayList();

    void listOfaccount() {
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;
        try {
            f = new File("user.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            User u;
            try {
                while (true) {
                    u = (User) ois.readObject();

                    if (u instanceof Trainer) {

                        totalTrainer.add(u.getName());
                    }
                }
            } catch (Exception e) {
            }
        } catch (IOException ex) {
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex) {
            }
        }
    }
}
