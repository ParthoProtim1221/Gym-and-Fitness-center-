/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserGuis.Admin;

import Classes.User;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.xml.crypto.Data;

/**
 * FXML Controller class
 *
 * @author AhNAF TAzWAR
 */
public class PieChartPanelController implements Initializable {

    @FXML
    private PieChart pieChart;
    @FXML
    private Label statusLabel;

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private void backOnClick(ActionEvent event) throws IOException {
        Parent scene2Parent = FXMLLoader.load(getClass().getResource("GenerateGraph.fxml"));
        Scene scene2 = new Scene(scene2Parent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(scene2);
        window.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        IDCounting();
        ObservableList <PieChart.Data> list = FXCollections.observableArrayList(
            new PieChart.Data("Manager",managertotal),
            new PieChart.Data("Trainer",trainertotal),
            new PieChart.Data("Member",membertotal)
        );
        pieChart.setData(list);
        
        for(PieChart.Data data: pieChart.getData()){
            data.getNode().addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>(){
                @Override
                public void handle(MouseEvent event) {
                    statusLabel.setText(String.valueOf(data.getPieValue()));
                   
                }
            }
            );
        }
  

        
        
    }    
    private int managertotal;
    private int trainertotal;
    private int membertotal;
    void IDCounting() 
    {
        
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        f = new File("user.bin");
        if (f.exists()){
            try {
                fis = new FileInputStream(f);
                ois = new ObjectInputStream(fis);
                User u;
                try {
                    while (true) {

                        u = (User) ois.readObject();
                        if(!u.getIsSuspend() && !u.getDeleteAccount()){
                        if(u.getId().charAt(0)=='2' )
                        {
                            managertotal+=1;
                        }
                        else if(u.getId().charAt(0)=='3')
                        {
                            trainertotal+=1;
                        }
                        else if(u.getId().charAt(0)=='4')
                        {
                            membertotal+=1;
                        }
                        }
                    }
                } catch (Exception e) {  }
            } catch (IOException ex) { } 
            finally {
                try {
                    if (ois != null) {
                        ois.close();
                    }
                } catch (IOException ex) {
                }
            }
        }
        
    }
}
