package ampm_gym_and_fitness;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
public class ProgrameController implements Initializable {

    @FXML
    private Label saloonLabel;
    @FXML
    private Label spaLabel;
    @FXML
    private Label gymLabel;
    @FXML
    private Label parlourLabel;

    @FXML
    private void backButtonOnClick(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        Scene scene = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene);
        window.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void salunButtonOnClick(Event event) {
           String str = "";
        File f = null;
        Scanner sc; String s; String[] tokens;
        try {
            f = new File("newAddedProgramInfo.txt");
            sc = new Scanner(f);
            if(f.exists()){
               
                while(sc.hasNextLine()){
                    s=sc.nextLine();
                    tokens = s.split("  ");
                               
                    if(tokens[1].equals(" Salun"))
                    {
                        str += s + " \n";
                       
                    }
                }
            }
           
                
        } 
        catch (IOException ex) {} 
        finally {
            saloonLabel.setText(str);
        }        
    }
    

    

    @FXML
    private void spaButtonOnClick(Event event) {
           String str = "";
        File f = null;
        Scanner sc; String s; String[] tokens;
        try {
            f = new File("newAddedProgramInfo.txt");
            sc = new Scanner(f);
            if(f.exists()){
               
                while(sc.hasNextLine()){
                    s=sc.nextLine();
                    tokens = s.split("  ");
                               
                    if(tokens[1].equals(" Spa"))
                    {
                        str += s + " \n";
                       
                    }
                }
            }
           
                
        } 
        catch (IOException ex) {} 
        finally {
            spaLabel.setText(str);
        }        
    }

    @FXML
    private void gymButtonOnClick(Event event) {
         String str = "";
        File f = null;
        Scanner sc; String s; String[] tokens;
        try {
            f = new File("newAddedProgramInfo.txt");
            sc = new Scanner(f);
            if(f.exists()){
               
                while(sc.hasNextLine()){
                    s=sc.nextLine();
                    tokens = s.split("  ");
                               
                    if(tokens[1].equals("GYM"))
                    {
                        str += s + "\n";
                    }
                }
            }
           
                
        } 
        catch (IOException ex) {} 
        finally {
            gymLabel.setText(str);
        }        

    }

    @FXML
    private void parlourButtonOnClick(Event event) {
             String str = "";
        File f = null;
        Scanner sc; String s; String[] tokens;
        try {
            f = new File("newAddedProgramInfo.txt");
            sc = new Scanner(f);
            if(f.exists()){
               
                while(sc.hasNextLine()){
                    s=sc.nextLine();
                    tokens = s.split("  ");
                           
                    if(tokens[1] == "Parlour" )
                    {
                        str += s + "\n";
                        System.out.println("s");
                    }
                }
            }
           
                
        } 
        catch (IOException ex) {} 
        finally {
            parlourLabel.setText(str);
        }
    }
    
}
